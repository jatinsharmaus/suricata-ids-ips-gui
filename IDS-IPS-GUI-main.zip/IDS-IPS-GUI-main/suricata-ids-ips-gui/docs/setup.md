# Setup Guide

## Requirements
- Kali Linux
- Root access
- Suricata installed

## Install Suricata
```bash
sudo apt update
sudo apt install suricata python3-tk -y
sudo python3 src/suricata_gui.py


