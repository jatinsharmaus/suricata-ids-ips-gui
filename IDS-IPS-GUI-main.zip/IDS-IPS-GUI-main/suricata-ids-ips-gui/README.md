# 🔐 Suricata IDS/IPS Real-Time Monitoring GUI

A real-world **Intrusion Detection and Prevention System (IDS/IPS)** project using **Suricata** and **Python GUI** for real-time network monitoring.

This tool visualizes Suricata alerts and protocol connections (SSH, FTP, Telnet, ICMP) in a live dashboard.

---

## 🚀 Features

- Real-time IDS alert detection
- SSH, FTP, Telnet, ICMP connection monitoring
- Suricata EVE JSON log parsing
- Severity-based filtering
- Modular Python code design
- SOC-style monitoring dashboard

---

## 🧠 Project Architecture


